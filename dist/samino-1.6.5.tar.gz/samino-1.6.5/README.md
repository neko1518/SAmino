<h1 align="center">
  <br>
  <a href="https://discord.gg/54E3j7eyDV"><img src="https://h.top4top.io/p_2088b2c5m1.jpg" width="600"></a>
  <br>
</h1>


### What is this lib?
Unofficial Amino API written in Python to easily connect Amino servers

### How to install?
`pip install SAmino`
- **FOCUS!:** type `SAmino` **Not** `Amino`

### API Reference documentation
Soon...

**CR**: Pysc Overall
